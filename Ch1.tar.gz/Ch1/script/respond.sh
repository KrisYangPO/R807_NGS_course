input=$1 

echo ${input}
