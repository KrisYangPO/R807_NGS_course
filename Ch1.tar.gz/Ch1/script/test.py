#!/usr/bin/python3

word = "HAHAHA"

print(word)

